MENU = '\n1. Mostrar codigos de sector y descripcion\n2. Mostrar el consumo por sector\n0. Salir\n'
FILE_DIRECTORY = 'files/Consum.csv'
PRINT2 = '\nEl total de consumo: '
ERROR = 'No se ha encontrado el archivo'