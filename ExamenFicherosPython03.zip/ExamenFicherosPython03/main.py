import literales as l
import functions as f

def main():

    fname = l.FILE_DIRECTORY
    f.read_file(fname)
    
if __name__ == "__main__":
    main()