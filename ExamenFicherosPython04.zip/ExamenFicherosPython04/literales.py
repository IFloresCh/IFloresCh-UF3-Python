FILE_DIRECTORY = 'files/libres_armari_biblioteca.csv'

MENU = '\n1. carregar els registres en la taula\n2. inserir nous registres en la taula\n3. Mostrar per pantalla les dades tabulades\n4. Mostrar el total de registres de la bbdd i el del csv\n'
NOM = 'Introduce el nombre del libro: '
AUTOR = 'Introduce el nombre del autor: '
DATE = 'Introduce el año/edicion: '
IDIOMA = 'Introduce el idioma: '
GENERO = 'Introduce el Género: '